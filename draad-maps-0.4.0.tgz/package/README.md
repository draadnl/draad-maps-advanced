# draad-maps

Web Components library for Dutch mapping applications built with Leaflet, proj4leaflet, and Vite.

## Features

- Declarative HTML API with custom elements
- Dutch coordinate system support (RD/EPSG:28992)
- WMS, WFS, GeoJSON layer support
- Interactive markers with hover/active states
- Real-time data filtering with auto-detected UI controls
- Address and feature search via PDOK Locatieserver
- Legend with layer toggle controls
- Shadow DOM style encapsulation
- WCAG 2.1 Level AA accessible

## Quick Start

```html
<dm-map>
  <!-- Optional: Add search for addresses and features -->
  <dm-search></dm-search>

  <!-- Optional: Add filter for data layers -->
  <dm-filter></dm-filter>

  <dm-layer name="markers" label="Locations">
    <dm-marker center="52.37,4.89" label="Amsterdam"></dm-marker>
  </dm-layer>

  <!-- Optional: Add filterable GeoJSON data -->
  <dm-layer name="data" label="Data">
    <dm-geojson
      src="https://example.com/data.geojson"
      filter-properties="category"
      filter-labels="Category">
    </dm-geojson>
  </dm-layer>

  <dm-legend slot="legend"></dm-legend>
</dm-map>
```

## Components

### `<dm-map>` - Map Container

The main container that initializes the Leaflet map.

```html
<dm-map>
  <!-- layers and content go here -->
  <dm-legend slot="legend"></dm-legend>
  <p slot="caption">Map caption text</p>
</dm-map>
```

### `<dm-layer>` - Layer Grouping

Groups map features together for visibility control.

| Attribute | Description |
|-----------|-------------|
| `name` | Unique identifier |
| `label` | Display name in legend |
| `visible` | Toggle visibility (`true`/`false`) |
| `filter-property` | Single property to filter by (legacy syntax) |
| `filter-label` | Label for single filter property |
| `filter-properties` | Comma-separated list of properties to filter by |
| `filter-labels` | Comma-separated labels for filter properties |

```html
<dm-layer name="points" label="Points of Interest" visible="true">
  <!-- markers, geojson, wfs, or wms -->
</dm-layer>
```

### `<dm-marker>` - Markers

Interactive map markers with customizable icons.

| Attribute | Description |
|-----------|-------------|
| `center` | Position as `"lat,lng"` (required) |
| `icon` | Default icon URL |
| `icon-hover` | Hover state icon URL |
| `icon-active` | Active state icon URL |
| `label` | Display name in legend |
| `visible` | Toggle visibility |

```html
<dm-marker
  center="52.158769,5.147094"
  icon="/markers/custom.png"
  icon-hover="/markers/custom-hover.png"
  label="My Location">
</dm-marker>
```

### `<dm-geojson>` - GeoJSON Data

Loads and displays GeoJSON data from a URL.

| Attribute | Description |
|-----------|-------------|
| `src` | GeoJSON endpoint URL (required) |
| `crs` | Coordinate system (e.g., `EPSG:28992`, `rd`, `wgs84`) |
| `label` | Display name in legend |
| `visible` | Toggle visibility |
| `filter-property` | Single property to filter by (legacy syntax) |
| `filter-label` | Label for single filter property |
| `filter-properties` | Comma-separated list of properties to filter by |
| `filter-labels` | Comma-separated labels for filter properties |

```html
<dm-geojson
  src="https://example.com/data.geojson"
  crs="EPSG:28992"
  label="Boundaries"
  filter-properties="type,status"
  filter-labels="Type,Status">
</dm-geojson>
```

### `<dm-wfs>` - WFS Features

Loads features from a Web Feature Service.

| Attribute | Description |
|-----------|-------------|
| `src` | WFS service URL (required) |
| `name` | Feature type name (required) |
| `version` | WFS version (default: `1.1.0`) |
| `format` | Output format (default: `application/json`) |
| `crs` | Coordinate system |
| `max-features` | Limit number of features |
| `proxy` | Proxy path for CORS |
| `label` | Display name in legend |
| `visible` | Toggle visibility |
| `filter-property` | Single property to filter by (legacy syntax) |
| `filter-label` | Label for single filter property |
| `filter-properties` | Comma-separated list of properties to filter by |
| `filter-labels` | Comma-separated labels for filter properties |

```html
<dm-wfs
  src="https://geodata.example.nl/geoserver/ows"
  name="namespace:layername"
  version="1.1.0"
  format="application/json"
  proxy="/geo-proxy"
  label="WFS Layer"
  filter-properties="category,year"
  filter-labels="Category,Year">
</dm-wfs>
```

### `<dm-wms>` - WMS Tiles

Displays tiles from a Web Map Service.

| Attribute | Description |
|-----------|-------------|
| `src` | WMS service URL (required) |
| `layers` | Layer name(s) (required) |
| `version` | WMS version (default: `1.1.1`) |
| `format` | Image format (default: `image/png`) |
| `transparent` | Transparency (default: `true`) |
| `opacity` | Layer opacity (0-1) |
| `crs` | Coordinate system |
| `proxy` | Proxy path for CORS |
| `label` | Display name in legend |
| `visible` | Toggle visibility |

```html
<dm-wms
  src="https://service.pdok.nl/cbs/wms/v1_0"
  layers="layername"
  version="1.1.1"
  opacity="0.7"
  label="WMS Layer">
</dm-wms>
```

### `<dm-legend>` - Layer Controls

Displays toggleable checkboxes for layers with a `label` attribute.

```html
<dm-map>
  <dm-layer name="data" label="My Data">
    <!-- content -->
  </dm-layer>
  <dm-legend slot="legend"></dm-legend>
</dm-map>
```

### `<dm-search>` - Address & Feature Search

Search Dutch addresses via PDOK Locatieserver API and features in data layers. Place anywhere inside `<dm-map>`.

| Attribute | Description |
|-----------|-------------|
| `placeholder` | Input placeholder text (default: `"Zoeken..."`) |
| `label` | Label text above input (default: `"Zoek op straat, wijk of stadsdeel"`) |
| `search-properties` | Comma-separated feature properties to search |
| `search-labels` | Display labels for search properties |
| `radius` | Zoom radius in meters for point results (default: `10000`) |
| `min-chars` | Minimum characters before search (default: `2`) |
| `debounce` | Debounce delay in ms (default: `300`) |

```html
<dm-map>
  <dm-search
    placeholder="Zoek een adres..."
    label="Zoeken"
    search-properties="name,description"
    search-labels="Naam,Omschrijving">
  </dm-search>

  <dm-layer name="locations" label="Locations">
    <dm-geojson src="locations.geojson"></dm-geojson>
  </dm-layer>
</dm-map>
```

#### Search Sources

The component searches:
1. **PDOK Locatieserver** - Dutch addresses, streets, neighborhoods, municipalities, provinces
2. **Data layer features** - Properties in `<dm-geojson>` and `<dm-wfs>` elements
3. **Markers** - `<dm-marker>` elements with a `label` attribute

#### Result Behavior

- **Address results**: Zooms to location with radius based on type (province: 50km, municipality: 20km, address: 10km)
- **Feature results**: Fits bounds for polygons/lines, or zooms to centroid for points
- **Geometry highlighting**: Polygons and lines from PDOK are highlighted on the map

### `<dm-filter>` - Data Filtering

Real-time filtering for GeoJSON and WFS data sources. Automatically detects property value types and generates appropriate UI controls.

Place `<dm-filter>` anywhere inside `<dm-map>` (not in slots):

```html
<dm-map>
  <!-- Filter component -->
  <dm-filter></dm-filter>

  <!-- Filterable data sources -->
  <dm-layer name="data" label="My Data">
    <dm-geojson
      id="data-source"
      src="https://example.com/data.geojson"
      filter-properties="category,status,year"
      filter-labels="Category,Status,Year">
    </dm-geojson>
  </dm-layer>

  <dm-legend slot="legend"></dm-legend>
</dm-map>
```

#### Making Data Sources Filterable

Add filter attributes to `<dm-geojson>`, `<dm-wfs>`, or `<dm-layer>` elements:

**Multi-property filtering** (recommended):
```html
<dm-geojson
  src="..."
  filter-properties="type,status,year"
  filter-labels="Type,Status,Year">
</dm-geojson>
```

**Single property filtering** (legacy syntax):
```html
<dm-geojson
  src="..."
  filter-property="type"
  filter-label="Type">
</dm-geojson>
```

#### Filter UI Types

The filter component automatically selects the appropriate UI based on value type and count:

| Value Type | Condition | UI Control | Description |
|------------|-----------|------------|-------------|
| Single value | Only 1 unique value | Read-only text | No filtering needed |
| Numeric | All values are numbers | Range slider (min/max) | Continuous range selection |
| Categorical | < 10 unique values | Checkboxes | Multi-select with visual clarity |
| Categorical | ≥ 10 unique values | Multi-select dropdown | Space-efficient for many options |

#### Filter Logic

- **Within a property**: Values are combined with OR logic (e.g., "type=A OR type=B")
- **Across properties**: Filters are combined with AND logic (e.g., "type=A AND status=active")
- **No selection**: When no values are selected or all values are selected, all features are shown
- **Real-time updates**: Filter changes are debounced (150ms) for performance

#### Accessibility Features

- WCAG 2.1 Level AA compliant
- Full keyboard navigation support
- Screen reader announcements for filter actions
- ARIA labels and roles throughout
- Focus management (returns to toggle button on close)

#### Performance

- Debounced range slider inputs (150ms delay)
- Efficient feature filtering using property lookups
- Minimal re-renders during interaction
- Cached value extraction from data sources

#### Example: Complex Filtering

```html
<dm-map>
  <dm-filter></dm-filter>

  <!-- Filter by multiple properties -->
  <dm-layer name="buildings" label="Buildings">
    <dm-geojson
      id="buildings-data"
      src="https://api.example.com/buildings.geojson"
      filter-properties="building_type,year_built,status,height_m"
      filter-labels="Building Type,Year Built,Status,Height (m)">
    </dm-geojson>
  </dm-layer>

  <!-- Filter WFS data -->
  <dm-layer name="parcels" label="Parcels">
    <dm-wfs
      id="parcels-data"
      src="https://geodata.example.nl/wfs"
      name="parcels"
      filter-properties="zone,owner_type"
      filter-labels="Zoning,Ownership">
    </dm-wfs>
  </dm-layer>

  <dm-legend slot="legend"></dm-legend>
</dm-map>
```

**Result**: Users can filter buildings by type (checkboxes), year range (slider), status (checkboxes), and height range (slider), while also filtering parcels by zone and ownership type. All filters work together with AND logic across different data sources.

## Events

```javascript
// Map ready
document.querySelector('dm-map').addEventListener('dm-map:ready', (e) => {
  const leafletMap = e.detail.map;
});

// Marker interactions
document.querySelector('dm-marker').addEventListener('dm-marker:click', (e) => {
  console.log('Clicked marker:', e.detail.targetId);
});

document.querySelector('dm-marker').addEventListener('dm-marker:hover', (e) => {
  console.log('Hovering:', e.detail.hovering);
});

// Layer data loaded
document.querySelector('dm-geojson').addEventListener('dm-geojson:ready', (e) => {
  console.log('GeoJSON data:', e.detail.data);
});

document.querySelector('dm-wfs').addEventListener('dm-wfs:ready', (e) => {
  console.log('WFS data:', e.detail.data);
});

// Filter applied (dispatched to filterable elements)
document.querySelector('#data-source').addEventListener('dm-filter:apply', (e) => {
  console.log('Filters applied:', e.detail.filters);
  // e.detail.filters = { propertyName: [values...] | { min, max } }
});

// Search result selected
document.querySelector('dm-search').addEventListener('dm-search:select', (e) => {
  console.log('Selected:', e.detail.label, e.detail.coordinates);
  // e.detail = { type, label, coordinates, bounds, feature, marker, raw }
});

// Search zoomed to result
document.querySelector('dm-search').addEventListener('dm-search:zoom', (e) => {
  console.log('Zoomed to:', e.detail.bounds);
});
```

## Development

```bash
npm run dev      # Start dev server with hot reload
npm run build    # Production build to /dist
npm run preview  # Preview production build
```

## Proxy Configuration

For WFS/WMS services that don't support CORS, configure a proxy in `vite.config.js`. The included `/geo-proxy` endpoint handles this with SSRF protection.

```html
<dm-wfs src="https://external-service.nl/wfs" proxy="/geo-proxy"></dm-wfs>
```
